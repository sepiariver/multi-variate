# MultiVariate

A collection of MODX Snippets and tools to handle simple multi-variate (A/B) testing.

